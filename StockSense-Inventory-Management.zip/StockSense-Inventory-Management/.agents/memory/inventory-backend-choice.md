---
name: Inventory backend choice
description: Why the initial StockSense inventory API is in-memory and what to change for production persistence.
---

StockSense currently keeps its seeded inventory state in the API process so the first build can demonstrate every stock workflow without requiring schema setup or migrations. This is intentional for the prototype and should be replaced with PostgreSQL persistence before real operational use.

**Why:** The product surface needed to be usable immediately, while durable inventory and audit data need transactional storage.

**How to apply:** Preserve the OpenAPI response shapes when moving the route handlers to Drizzle-backed repositories; keep stock mutations and ledger writes atomic.