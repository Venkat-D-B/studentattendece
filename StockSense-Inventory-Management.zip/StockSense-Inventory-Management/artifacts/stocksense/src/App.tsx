import { useMemo, useState } from 'react';
import { QueryClient, QueryClientProvider, useQueryClient } from '@tanstack/react-query';
import { ClerkProvider, Show, SignIn, SignUp, useClerk, useUser } from '@clerk/react';
import { publishableKeyFromHost } from '@clerk/react/internal';
import { shadcn } from '@clerk/themes';
import { Link, Route, Router as WouterRouter, Switch, useLocation } from 'wouter';
import {
  AlertTriangle, ArrowDownToLine, ArrowLeftRight, ArrowRight, Bell, Boxes, Check,
  ChevronRight, CircleCheck, CircleX, ClipboardCheck, LayoutDashboard, ListTree, MapPin,
  Menu, PackageOpen, Plus, RefreshCw, Search, Settings as SettingsIcon, SlidersHorizontal,
  Tags, Truck, UserCircle, Warehouse as WarehouseIcon, X,
} from 'lucide-react';
import {
  getGetDashboardSummaryQueryKey, getGetProductQueryKey,
  getListAdjustmentsQueryKey, getListCategoriesQueryKey, getListDeliveriesQueryKey,
  getListLedgerQueryKey, getListProductsQueryKey, getListReceiptsQueryKey,
  getListTransfersQueryKey, getListWarehousesQueryKey, useCreateAdjustment, useCreateCategory,
  useCreateDelivery, useCreateProduct, useCreateReceipt, useCreateTransfer, useCreateWarehouse,
  useGetDashboardSummary, useGetProduct, useGetRecentActivity, useListAdjustments,
  useListCategories, useListDeliveries, useListLedger, useListProducts, useListReceipts,
  useListTransfers, useListWarehouses, useUpdateProduct, useValidateAdjustment,
  useValidateDelivery, useValidateReceipt, useValidateTransfer,
} from '@workspace/api-client-react';
import type {
  Adjustment, Activity, DashboardSummary, LedgerEntry, Product, StockDocument, Transfer,
} from '@workspace/api-client-react';
import { ErrorBoundary } from '@/components/error-boundary';
import NotFound from '@/pages/not-found';
import { Toaster } from '@/components/ui/toaster';
import { TooltipProvider } from '@/components/ui/tooltip';

const queryClient = new QueryClient();
const basePath = import.meta.env.BASE_URL.replace(/\/$/, '');
const clerkPubKey = publishableKeyFromHost(
  window.location.hostname,
  import.meta.env.VITE_CLERK_PUBLISHABLE_KEY,
);
const clerkProxyUrl = import.meta.env.VITE_CLERK_PROXY_URL;
const clerkAppearance = {
  theme: shadcn,
  cssLayerName: 'clerk',
  options: {
    logoPlacement: 'inside' as const,
    logoLinkUrl: basePath || '/',
    logoImageUrl: `${window.location.origin}${basePath}/logo.svg`,
  },
  variables: {
    colorPrimary: '#267d70',
    colorForeground: '#1e2a36',
    colorMutedForeground: '#6f7a82',
    colorDanger: '#c8483e',
    colorBackground: '#fffdf9',
    colorInput: '#f4f0e8',
    colorInputForeground: '#1e2a36',
    colorNeutral: '#d9d5cc',
    fontFamily: 'Manrope, sans-serif',
    borderRadius: '0.55rem',
  },
  elements: {
    rootBox: 'w-full flex justify-center',
    cardBox: 'bg-[#fffdf9] rounded-2xl w-[440px] max-w-full overflow-hidden',
    card: '!shadow-none !border-0 !bg-transparent !rounded-none',
    footer: '!shadow-none !border-0 !bg-transparent !rounded-none',
    headerTitle: 'text-[#1e2a36] font-extrabold',
    headerSubtitle: 'text-[#6f7a82]',
    socialButtonsBlockButtonText: 'text-[#1e2a36]',
    formFieldLabel: 'text-[#1e2a36]',
    footerActionLink: 'text-[#267d70] font-semibold',
    footerActionText: 'text-[#6f7a82]',
    dividerText: 'text-[#6f7a82]',
    identityPreviewEditButton: 'text-[#267d70]',
    formFieldSuccessText: 'text-[#267d70]',
    alertText: 'text-[#c8483e]',
    logoBox: 'mb-4',
    logoImage: 'h-9 w-auto',
    socialButtonsBlockButton: 'border-[#d9d5cc] bg-[#fffdf9]',
    formButtonPrimary: 'bg-[#267d70] hover:bg-[#206b60]',
    formFieldInput: 'border-[#d9d5cc] bg-[#f4f0e8] text-[#1e2a36]',
    footerAction: 'border-t border-[#d9d5cc] pt-4',
    dividerLine: 'bg-[#d9d5cc]',
    alert: 'border-[#f0c6c1] bg-[#fff2f0]',
    otpCodeFieldInput: 'border-[#d9d5cc] bg-[#f4f0e8]',
    formFieldRow: 'gap-1',
    main: 'gap-5',
  },
};

const nav = [
  { href: '/', label: 'Overview', icon: LayoutDashboard },
  { href: '/products', label: 'Products', icon: Boxes },
  { href: '/receipts', label: 'Receipts', icon: ArrowDownToLine },
  { href: '/deliveries', label: 'Deliveries', icon: Truck },
  { href: '/transfers', label: 'Transfers', icon: ArrowLeftRight },
  { href: '/adjustments', label: 'Adjustments', icon: ClipboardCheck },
  { href: '/ledger', label: 'Ledger', icon: ListTree },
];

const formatNumber = (value?: number) => new Intl.NumberFormat('en-US').format(value ?? 0);
const formatCurrency = (value?: number) => new Intl.NumberFormat('en-US', { style: 'currency', currency: 'USD', maximumFractionDigits: 0 }).format(value ?? 0);
const dateLabel = (date?: string) => date ? new Intl.DateTimeFormat('en-US', { month: 'short', day: 'numeric', year: 'numeric' }).format(new Date(date)) : '—';
const timeLabel = (date?: string) => date ? new Intl.DateTimeFormat('en-US', { hour: 'numeric', minute: '2-digit' }).format(new Date(date)) : '—';

function LoadingRows({ count = 4 }: { count?: number }) {
  return <div className="space-y-2 p-4" data-testid="loading-state">{Array.from({ length: count }).map((_, i) => <div key={i} className="h-12 animate-pulse rounded bg-muted/70" />)}</div>;
}

function QueryState({ error, onRetry }: { error?: unknown; onRetry: () => void }) {
  return <div className="flex min-h-40 flex-col items-center justify-center gap-3 rounded-lg border border-dashed border-destructive/40 bg-destructive/5 p-8 text-center" data-testid="error-state">
    <CircleX className="h-7 w-7 text-destructive" /><p className="text-sm text-muted-foreground">The workspace could not load this view.</p>
    <button data-testid="button-retry" onClick={onRetry} className="focus-ring inline-flex items-center gap-2 rounded-md border border-border bg-card px-3 py-2 text-xs font-semibold hover:bg-muted"><RefreshCw className="h-3.5 w-3.5" /> Retry</button>
    {error instanceof Error && <span className="sr-only">{error.message}</span>}
  </div>;
}

function EmptyState({ title, detail }: { title: string; detail: string }) {
  return <div className="flex min-h-48 flex-col items-center justify-center gap-2 rounded-lg border border-dashed border-border bg-card/60 p-8 text-center" data-testid="empty-state">
    <PackageOpen className="h-8 w-8 text-muted-foreground/60" /><p className="font-semibold">{title}</p><p className="max-w-sm text-sm text-muted-foreground">{detail}</p>
  </div>;
}

function StatusPill({ status }: { status: string }) {
  const tone = status === 'done' || status === 'healthy' ? 'good' : status === 'low' || status === 'waiting' || status === 'ready' || status === 'draft' ? 'warn' : 'bad';
  return <span data-testid={`status-${status}`} className={`inline-flex items-center gap-1.5 rounded-full px-2 py-1 text-[10px] font-bold uppercase tracking-wider ${tone === 'good' ? 'bg-primary/10 text-primary' : tone === 'warn' ? 'bg-accent/15 text-amber-700' : 'bg-destructive/10 text-destructive'}`}><span className={`h-1.5 w-1.5 rounded-full ${tone === 'good' ? 'bg-primary' : tone === 'warn' ? 'bg-accent' : 'bg-destructive'}`} />{status}</span>;
}

function Modal({ title, open, onClose, children }: { title: string; open: boolean; onClose: () => void; children: React.ReactNode }) {
  if (!open) return null;
  return <div className="fixed inset-0 z-50 flex items-end justify-center bg-foreground/30 p-0 backdrop-blur-sm sm:items-center sm:p-6" role="dialog" aria-modal="true">
    <div className="max-h-[92dvh] w-full overflow-y-auto rounded-t-xl border border-border bg-card shadow-2xl sm:max-w-lg sm:rounded-xl">
      <div className="flex items-center justify-between border-b border-border px-5 py-4"><div><p className="font-mono-ui text-[10px] uppercase tracking-[.18em] text-primary">StockSense / input</p><h2 className="mt-1 text-lg font-bold">{title}</h2></div><button data-testid="button-close-modal" onClick={onClose} className="focus-ring rounded-md p-2 text-muted-foreground hover:bg-muted"><X className="h-4 w-4" /></button></div>
      <div className="p-5">{children}</div>
    </div>
  </div>;
}

function Field({ label, children }: { label: string; children: React.ReactNode }) {
  return <label className="grid gap-1.5 text-xs font-semibold text-muted-foreground">{label}{children}</label>;
}

function TextInput(props: React.InputHTMLAttributes<HTMLInputElement>) {
  return <input {...props} className="focus-ring h-10 w-full rounded-md border border-input bg-background px-3 text-sm outline-none placeholder:text-muted-foreground/60" />;
}

function Shell({ children }: { children: React.ReactNode }) {
  const [location] = useLocation();
  const [mobileOpen, setMobileOpen] = useState(false);
  const current = nav.find((item) => item.href === location)?.label ?? (location === '/settings' ? 'Settings' : 'Profile');
  return <div className="min-h-[100dvh] bg-background">
    <aside className={`fixed inset-y-0 left-0 z-40 flex w-[244px] flex-col bg-sidebar text-sidebar-foreground transition-transform duration-200 md:translate-x-0 ${mobileOpen ? 'translate-x-0' : '-translate-x-full'}`}>
      <div className="flex h-20 items-center gap-3 border-b border-sidebar-border px-5">
        <div className="grid h-9 w-9 place-items-center rounded-lg bg-sidebar-primary text-sidebar-primary-foreground"><ScanLineIcon /></div>
        <div><div className="font-mono-ui text-[13px] font-medium tracking-tight">STOCK<span className="text-sidebar-primary">SENSE</span></div><div className="mt-0.5 text-[9px] uppercase tracking-[.2em] text-sidebar-foreground/50">Operations control</div></div>
      </div>
      <div className="px-4 pt-6"><p className="mb-2 px-2 text-[10px] font-bold uppercase tracking-[.18em] text-sidebar-foreground/40">Workspace</p><nav className="space-y-1">{nav.map(({ href, label, icon: Icon }) => <Link key={href} href={href} data-testid={`link-nav-${label.toLowerCase()}`} onClick={() => setMobileOpen(false)} className={`group flex items-center gap-3 rounded-md px-3 py-2.5 text-sm font-semibold transition-colors ${location === href ? 'bg-sidebar-accent text-sidebar-accent-foreground' : 'text-sidebar-foreground/65 hover:bg-sidebar-accent/70 hover:text-sidebar-foreground'}`}><Icon className={`h-[17px] w-[17px] ${location === href ? 'text-sidebar-primary' : ''}`} /><span>{label}</span>{location === href && <span className="ml-auto h-1.5 w-1.5 rounded-full bg-sidebar-primary" />}</Link>)}</nav></div>
      <div className="mt-auto space-y-1 border-t border-sidebar-border p-4">
        <Link href="/settings" data-testid="link-nav-settings" className={`flex items-center gap-3 rounded-md px-3 py-2.5 text-sm font-semibold ${location === '/settings' ? 'bg-sidebar-accent text-sidebar-accent-foreground' : 'text-sidebar-foreground/65 hover:bg-sidebar-accent/70 hover:text-sidebar-foreground'}`}><SettingsIcon className="h-[17px] w-[17px]" /> Settings</Link>
        <Link href="/profile" data-testid="link-nav-profile" className={`flex items-center gap-3 rounded-md px-3 py-2.5 text-sm font-semibold ${location === '/profile' ? 'bg-sidebar-accent text-sidebar-accent-foreground' : 'text-sidebar-foreground/65 hover:bg-sidebar-accent/70 hover:text-sidebar-foreground'}`}><UserCircle className="h-[17px] w-[17px]" /> Profile</Link>
        <div className="mt-4 flex items-center gap-3 rounded-md bg-sidebar-accent/60 p-3"><div className="grid h-8 w-8 place-items-center rounded-full bg-accent text-xs font-extrabold text-accent-foreground">MC</div><div className="min-w-0"><p className="truncate text-xs font-bold">Morgan Chen</p><p className="truncate text-[10px] text-sidebar-foreground/50">Inventory manager</p></div></div>
      </div>
    </aside>
    {mobileOpen && <button aria-label="Close navigation" data-testid="button-close-navigation" onClick={() => setMobileOpen(false)} className="fixed inset-0 z-30 bg-foreground/30 md:hidden" />}
    <main className="md:pl-[244px]">
      <header className="sticky top-0 z-20 flex h-16 items-center justify-between border-b border-border bg-background/95 px-4 backdrop-blur md:px-8">
        <div className="flex items-center gap-3"><button data-testid="button-open-navigation" onClick={() => setMobileOpen(true)} className="rounded-md p-2 hover:bg-muted md:hidden"><Menu className="h-5 w-5" /></button><div><p className="text-[10px] font-bold uppercase tracking-[.2em] text-muted-foreground">Workspace / {current}</p><h1 className="text-sm font-extrabold tracking-tight md:text-base">{current}</h1></div></div>
        <div className="flex items-center gap-2"><span className="hidden items-center gap-2 rounded-full border border-primary/20 bg-primary/5 px-3 py-1.5 text-[10px] font-bold text-primary sm:flex"><span className="live-dot h-1.5 w-1.5 rounded-full bg-primary" /> Live sync</span><Show when="signed-out"><Link href="/sign-in" className="rounded-md border border-border bg-card px-3 py-2 text-xs font-bold hover:bg-muted">Sign in</Link></Show><button data-testid="button-notifications" className="rounded-md p-2 text-muted-foreground hover:bg-muted"><Bell className="h-4 w-4" /></button><Link href="/profile" data-testid="link-header-profile" className="grid h-8 w-8 place-items-center rounded-full bg-accent text-xs font-extrabold text-accent-foreground">MC</Link></div>
      </header>
      <div className="mx-auto max-w-[1440px] p-4 md:p-8">{children}</div>
    </main>
  </div>;
}

function ScanLineIcon() { return <span className="relative block h-5 w-5"><span className="absolute left-0 top-1 h-3 w-1 rounded bg-current" /><span className="absolute left-2 top-0 h-5 w-1 rounded bg-current" /><span className="absolute left-4 top-1 h-3 w-1 rounded bg-current" /></span>; }

function PageHeading({ eyebrow, title, detail, action }: { eyebrow: string; title: string; detail: string; action?: React.ReactNode }) {
  return <div className="mb-7 flex flex-col justify-between gap-4 sm:flex-row sm:items-end"><div><p className="font-mono-ui text-[10px] font-medium uppercase tracking-[.2em] text-primary">{eyebrow}</p><h2 className="mt-1 text-2xl font-extrabold tracking-tight md:text-3xl">{title}</h2><p className="mt-1 text-sm text-muted-foreground">{detail}</p></div>{action}</div>;
}

function Button({ children, variant = 'primary', onClick, type = 'button', testId }: { children: React.ReactNode; variant?: 'primary' | 'secondary' | 'ghost'; onClick?: () => void; type?: 'button' | 'submit'; testId?: string }) {
  return <button type={type} data-testid={testId} onClick={onClick} className={`focus-ring inline-flex h-10 items-center justify-center gap-2 rounded-md px-3.5 text-xs font-bold transition-colors ${variant === 'primary' ? 'bg-primary text-primary-foreground hover:bg-primary/90' : variant === 'secondary' ? 'border border-border bg-card text-foreground hover:bg-muted' : 'text-muted-foreground hover:bg-muted hover:text-foreground'}`}>{children}</button>;
}

function Dashboard() {
  const summary = useGetDashboardSummary();
  const activity = useGetRecentActivity({ limit: 8 });
  const s = summary.data as DashboardSummary | undefined;
  return <div className="animate-rise">
    <PageHeading eyebrow="Live inventory / 01" title="Good morning, Morgan." detail="Here is the operational picture across your network." action={<Link href="/products" data-testid="link-view-catalog" className="focus-ring inline-flex h-10 items-center gap-2 rounded-md border border-border bg-card px-3.5 text-xs font-bold hover:bg-muted"><Boxes className="h-4 w-4 text-primary" /> View catalog</Link>} />
    {summary.isLoading ? <LoadingRows count={3} /> : summary.isError ? <QueryState error={summary.error} onRetry={() => summary.refetch()} /> : <>
      <section className="grid gap-3 sm:grid-cols-2 xl:grid-cols-4">
        <MetricCard label="Total units on hand" value={formatNumber(s?.totalUnits)} detail="Across all locations" icon={<Boxes />} />
        <MetricCard label="Product lines" value={formatNumber(s?.productCount)} detail="Active catalog items" icon={<PackageOpen />} />
        <MetricCard label="Needs attention" value={formatNumber((s?.lowStockCount ?? 0) + (s?.outOfStockCount ?? 0))} detail={`${s?.lowStockCount ?? 0} low · ${s?.outOfStockCount ?? 0} out of stock`} icon={<AlertTriangle />} danger />
        <MetricCard label="Inbound value" value={formatCurrency(s?.inboundValue)} detail={`${s?.pendingReceipts ?? 0} receipts pending`} icon={<ArrowDownToLine />} />
      </section>
      <section className="mt-5 grid gap-5 xl:grid-cols-[1.45fr_1fr]">
        <div className="rounded-lg border border-card-border bg-card p-5 shadow-sm"><div className="mb-5 flex items-center justify-between"><div><p className="font-mono-ui text-[10px] uppercase tracking-[.18em] text-muted-foreground">Inventory mix</p><h3 className="mt-1 font-bold">Units by category</h3></div><Link href="/products" data-testid="link-category-breakdown" className="text-xs font-bold text-primary">Catalog <ChevronRight className="ml-1 inline h-3 w-3" /></Link></div><CategoryBars categories={s?.byCategory ?? []} /></div>
        <div className="rounded-lg border border-card-border bg-card p-5 shadow-sm"><div className="mb-5 flex items-center justify-between"><div><p className="font-mono-ui text-[10px] uppercase tracking-[.18em] text-muted-foreground">Queue monitor</p><h3 className="mt-1 font-bold">Next actions</h3></div><span className="rounded bg-muted px-2 py-1 font-mono-ui text-[10px] text-muted-foreground">TODAY</span></div><div className="space-y-1"><QueueRow label="Receipts to validate" value={s?.pendingReceipts ?? 0} href="/receipts" icon={<ArrowDownToLine />} /><QueueRow label="Deliveries to validate" value={s?.pendingDeliveries ?? 0} href="/deliveries" icon={<Truck />} /><QueueRow label="Scheduled transfers" value={s?.scheduledTransfers ?? 0} href="/transfers" icon={<ArrowLeftRight />} /></div><div className="mt-5 border-t border-border pt-4"><div className="flex items-center justify-between text-xs"><span className="text-muted-foreground">Outbound value</span><span className="font-mono-ui font-medium">{formatCurrency(s?.outboundValue)}</span></div></div></div>
      </section>
      <section className="mt-5 rounded-lg border border-card-border bg-card shadow-sm"><div className="flex items-center justify-between border-b border-border px-5 py-4"><div><p className="font-mono-ui text-[10px] uppercase tracking-[.18em] text-muted-foreground">Event stream</p><h3 className="mt-1 font-bold">Recent activity</h3></div><Link href="/ledger" data-testid="link-view-ledger" className="text-xs font-bold text-primary">Full ledger <ChevronRight className="ml-1 inline h-3 w-3" /></Link></div>{activity.isLoading ? <LoadingRows count={4} /> : activity.isError ? <QueryState error={activity.error} onRetry={() => activity.refetch()} /> : (activity.data as Activity[] | undefined)?.length ? <ActivityList items={activity.data as Activity[]} /> : <EmptyState title="No activity yet" detail="Validated stock movements will show up here." />}</section>
    </>}
  </div>;
}

function MetricCard({ label, value, detail, icon, danger }: { label: string; value: string; detail: string; icon: React.ReactNode; danger?: boolean }) {
  return <div className="rounded-lg border border-card-border bg-card p-4 shadow-sm"><div className={`mb-4 grid h-8 w-8 place-items-center rounded-md ${danger ? 'bg-destructive/10 text-destructive' : 'bg-primary/10 text-primary'}`}>{icon}</div><p className="text-xs font-semibold text-muted-foreground">{label}</p><p className="mt-1 font-mono-ui text-2xl font-medium tracking-tight">{value}</p><p className="mt-1 text-[11px] text-muted-foreground">{detail}</p></div>;
}

function CategoryBars({ categories }: { categories: { category: string; units: number; percentage: number }[] }) {
  const colors = ['bg-primary', 'bg-accent', 'bg-sky-600', 'bg-amber-500', 'bg-destructive'];
  if (!categories.length) return <EmptyState title="No category mix" detail="Category data will appear when inventory is available." />;
  return <div className="space-y-4">{categories.slice(0, 5).map((item, index) => <div key={item.category} data-testid={`row-category-${item.category}`}><div className="mb-1.5 flex justify-between text-xs"><span className="font-semibold">{item.category}</span><span className="font-mono-ui text-muted-foreground">{formatNumber(item.units)} <span className="text-[10px]">/ {item.percentage}%</span></span></div><div className="h-2 overflow-hidden rounded-full bg-muted"><div className={`h-full rounded-full ${colors[index % colors.length]}`} style={{ width: `${Math.min(item.percentage, 100)}%` }} /></div></div>)}</div>;
}

function QueueRow({ label, value, href, icon }: { label: string; value: number; href: string; icon: React.ReactNode }) {
  return <Link href={href} data-testid={`link-queue-${label.toLowerCase().replaceAll(' ', '-')}`} className="group flex items-center gap-3 rounded-md px-2 py-3 hover:bg-muted"><span className="grid h-8 w-8 place-items-center rounded-md bg-secondary text-secondary-foreground">{icon}</span><span className="flex-1 text-xs font-semibold">{label}</span><span className="font-mono-ui text-sm font-medium">{value}</span><ChevronRight className="h-4 w-4 text-muted-foreground transition-transform group-hover:translate-x-0.5" /></Link>;
}

function ActivityList({ items }: { items: Activity[] }) {
  return <div className="divide-y divide-border">{items.map((item) => <div className="flex items-center gap-3 px-5 py-3.5" key={item.id} data-testid={`row-activity-${item.id}`}><div className={`grid h-8 w-8 shrink-0 place-items-center rounded-md ${item.type === 'receipt' ? 'bg-primary/10 text-primary' : item.type === 'delivery' ? 'bg-accent/15 text-amber-700' : 'bg-secondary text-secondary-foreground'}`}>{item.type === 'receipt' ? <ArrowDownToLine className="h-4 w-4" /> : item.type === 'delivery' ? <Truck className="h-4 w-4" /> : <ArrowLeftRight className="h-4 w-4" />}</div><div className="min-w-0 flex-1"><p className="truncate text-xs font-bold">{item.title}</p><p className="truncate text-[11px] text-muted-foreground">{item.detail}</p></div><div className="text-right"><p className="font-mono-ui text-xs">{item.quantity > 0 ? `+${formatNumber(item.quantity)}` : formatNumber(item.quantity)}</p><p className="text-[10px] text-muted-foreground">{timeLabel(item.timestamp)}</p></div><StatusPill status={item.status} /></div>)}</div>;
}

function ProductPage() {
  const [search, setSearch] = useState('');
  const [status, setStatus] = useState('all');
  const [selectedId, setSelectedId] = useState<number | null>(null);
  const [createOpen, setCreateOpen] = useState(false);
  const query = useListProducts({ search: search || undefined });
  const products = ((query.data as Product[] | undefined) ?? []).filter((p) => status === 'all' || p.status === status);
  const categories = useListCategories();
  const create = useCreateProduct();
  const update = useUpdateProduct();
  const detail = useGetProduct(selectedId ?? 0, { query: { enabled: !!selectedId, queryKey: getGetProductQueryKey(selectedId ?? 0) } });
  const [form, setForm] = useState({ name: '', sku: '', category: '', unit: 'units', initialStock: '0', reorderPoint: '10' });
  const [editPoint, setEditPoint] = useState('');
  const submit = (event: React.FormEvent) => { event.preventDefault(); create.mutate({ data: { ...form, initialStock: Number(form.initialStock), reorderPoint: Number(form.reorderPoint) } }, { onSuccess: () => { queryClient.invalidateQueries({ queryKey: getListProductsQueryKey() }); setCreateOpen(false); setForm({ name: '', sku: '', category: '', unit: 'units', initialStock: '0', reorderPoint: '10' }); } }); };
  const startEdit = (p: Product) => { setSelectedId(p.id); setEditPoint(String(p.reorderPoint)); };
  const saveEdit = () => { if (!selectedId) return; update.mutate({ id: selectedId, data: { reorderPoint: Number(editPoint) } }, { onSuccess: () => { queryClient.invalidateQueries({ queryKey: getListProductsQueryKey() }); } }); };
  return <div className="animate-rise"><PageHeading eyebrow="Inventory / catalog" title="Product catalog" detail="Search, scan, and act on stock across every location." action={<Button onClick={() => setCreateOpen(true)} testId="button-create-product"><Plus className="h-4 w-4" /> Add product</Button>} />
    <div className="mb-4 flex flex-col gap-2 sm:flex-row"><div className="relative flex-1"><Search className="absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-muted-foreground" /><TextInput data-testid="input-product-search" value={search} onChange={(e) => setSearch(e.target.value)} placeholder="Search product name or SKU" className="pl-9" /></div><div className="flex rounded-md border border-border bg-card p-1">{['all', 'healthy', 'low', 'out'].map((item) => <button key={item} data-testid={`button-filter-${item}`} onClick={() => setStatus(item)} className={`rounded px-3 py-1.5 text-[11px] font-bold capitalize ${status === item ? 'bg-primary text-primary-foreground' : 'text-muted-foreground hover:bg-muted'}`}>{item === 'out' ? 'Out of stock' : item}</button>)}</div></div>
    <div className="overflow-hidden rounded-lg border border-card-border bg-card shadow-sm">{query.isLoading ? <LoadingRows /> : query.isError ? <QueryState error={query.error} onRetry={() => query.refetch()} /> : products.length === 0 ? <EmptyState title="No products match" detail="Try a different search or add the first product to your catalog." /> : <div className="overflow-x-auto"><table className="w-full min-w-[760px] text-left"><thead className="bg-muted/60 text-[10px] uppercase tracking-[.14em] text-muted-foreground"><tr><th className="px-5 py-3 font-bold">Product</th><th className="px-3 py-3 font-bold">Category</th><th className="px-3 py-3 font-bold">On hand</th><th className="px-3 py-3 font-bold">Reorder at</th><th className="px-3 py-3 font-bold">Locations</th><th className="px-3 py-3 font-bold">Status</th><th className="px-5 py-3" /></tr></thead><tbody className="divide-y divide-border">{products.map((product) => <tr key={product.id} data-testid={`row-product-${product.id}`} onClick={() => startEdit(product)} className="cursor-pointer hover:bg-muted/40"><td className="px-5 py-4"><p className="text-sm font-bold">{product.name}</p><p className="font-mono-ui text-[10px] text-muted-foreground">{product.sku}</p></td><td className="px-3 py-4 text-xs">{product.category}</td><td className="px-3 py-4"><span className="font-mono-ui text-sm">{formatNumber(product.totalStock)}</span> <span className="text-[10px] text-muted-foreground">{product.unit}</span></td><td className="px-3 py-4 font-mono-ui text-xs">{formatNumber(product.reorderPoint)}</td><td className="px-3 py-4 text-xs text-muted-foreground">{product.locations?.length ?? 0} locations</td><td className="px-3 py-4"><StatusPill status={product.status} /></td><td className="px-5 py-4 text-right"><ChevronRight className="ml-auto h-4 w-4 text-muted-foreground" /></td></tr>)}</tbody></table></div>}</div>
    <Modal title={detail.data ? (detail.data as Product).name : 'Product details'} open={!!selectedId} onClose={() => setSelectedId(null)}>{detail.isLoading ? <LoadingRows count={2} /> : detail.isError ? <QueryState error={detail.error} onRetry={() => detail.refetch()} /> : detail.data && <ProductDetail product={detail.data as Product} editPoint={editPoint} setEditPoint={setEditPoint} onSave={saveEdit} saving={update.isPending} />}</Modal>
    <Modal title="Add product" open={createOpen} onClose={() => setCreateOpen(false)}><form onSubmit={submit} className="grid gap-4"><Field label="Product name"><TextInput required data-testid="input-product-name" value={form.name} onChange={(e) => setForm({ ...form, name: e.target.value })} placeholder="e.g. 12mm hex bolt" /></Field><div className="grid grid-cols-2 gap-3"><Field label="SKU"><TextInput required data-testid="input-product-sku" value={form.sku} onChange={(e) => setForm({ ...form, sku: e.target.value })} placeholder="HW-1200" /></Field><Field label="Unit"><TextInput required data-testid="input-product-unit" value={form.unit} onChange={(e) => setForm({ ...form, unit: e.target.value })} /></Field></div><Field label="Category"><select required data-testid="select-product-category" value={form.category} onChange={(e) => setForm({ ...form, category: e.target.value })} className="focus-ring h-10 rounded-md border border-input bg-background px-3 text-sm">{(categories.data as { name: string }[] | undefined)?.map((c) => <option key={c.name} value={c.name}>{c.name}</option>)}<option value="">Uncategorized</option></select></Field><div className="grid grid-cols-2 gap-3"><Field label="Initial stock"><TextInput required type="number" min="0" data-testid="input-product-stock" value={form.initialStock} onChange={(e) => setForm({ ...form, initialStock: e.target.value })} /></Field><Field label="Reorder point"><TextInput required type="number" min="0" data-testid="input-product-reorder" value={form.reorderPoint} onChange={(e) => setForm({ ...form, reorderPoint: e.target.value })} /></Field></div><Button type="submit" testId="button-submit-product">{create.isPending ? 'Creating…' : 'Create product'}</Button></form></Modal>
  </div>;
}

function ProductDetail({ product, editPoint, setEditPoint, onSave, saving }: { product: Product; editPoint: string; setEditPoint: (v: string) => void; onSave: () => void; saving: boolean }) {
  return <div className="space-y-5"><div className="grid grid-cols-3 gap-2">{[['On hand', formatNumber(product.totalStock)], ['Unit', product.unit], ['Updated', dateLabel(product.updatedAt)]].map(([label, value]) => <div key={label} className="rounded-md bg-muted/70 p-3"><p className="text-[10px] uppercase tracking-wider text-muted-foreground">{label}</p><p className="mt-1 font-mono-ui text-sm">{value}</p></div>)}</div><div className="grid gap-1.5"><label className="text-xs font-semibold text-muted-foreground">Reorder point</label><div className="flex gap-2"><TextInput data-testid="input-edit-reorder" type="number" value={editPoint} onChange={(e) => setEditPoint(e.target.value)} /><Button onClick={onSave} testId="button-save-product">{saving ? 'Saving…' : 'Save'}</Button></div></div><div><p className="mb-2 text-xs font-semibold text-muted-foreground">Stock by location</p><div className="divide-y divide-border rounded-md border border-border">{product.locations?.map((location) => <div key={location.location} className="flex justify-between px-3 py-2.5 text-xs"><span className="flex items-center gap-2"><MapPin className="h-3.5 w-3.5 text-primary" />{location.location}</span><span className="font-mono-ui">{formatNumber(location.units)} {product.unit}</span></div>)}</div></div></div>;
}

type DocumentKind = 'receipts' | 'deliveries';
function DocumentsPage({ kind }: { kind: DocumentKind }) {
  const isReceipt = kind === 'receipts';
  const query = isReceipt ? useListReceipts() : useListDeliveries();
  const createReceipt = useCreateReceipt();
  const createDelivery = useCreateDelivery();
  const validateReceipt = useValidateReceipt();
  const validateDelivery = useValidateDelivery();
  const products = useListProducts();
  const warehouses = useListWarehouses();
  const [open, setOpen] = useState(false);
  const [form, setForm] = useState({ partner: '', location: '', productId: '', quantity: '1' });
  const items = (query.data as StockDocument[] | undefined) ?? [];
  const submit = (event: React.FormEvent) => { event.preventDefault(); const data = { partner: form.partner, location: form.location, productId: Number(form.productId), quantity: Number(form.quantity) }; const done = () => { queryClient.invalidateQueries({ queryKey: isReceipt ? getListReceiptsQueryKey() : getListDeliveriesQueryKey() }); queryClient.invalidateQueries({ queryKey: getGetDashboardSummaryQueryKey() }); setOpen(false); }; if (isReceipt) createReceipt.mutate({ data }, { onSuccess: done }); else createDelivery.mutate({ data }, { onSuccess: done }); };
  const validate = (id: number) => { if (isReceipt) validateReceipt.mutate({ id }, { onSuccess: () => { queryClient.invalidateQueries({ queryKey: getListReceiptsQueryKey() }); queryClient.invalidateQueries({ queryKey: getGetDashboardSummaryQueryKey() }); } }); else validateDelivery.mutate({ id }, { onSuccess: () => { queryClient.invalidateQueries({ queryKey: getListDeliveriesQueryKey() }); queryClient.invalidateQueries({ queryKey: getGetDashboardSummaryQueryKey() }); } }); };
  const title = isReceipt ? 'Incoming receipts' : 'Outgoing deliveries';
  return <div className="animate-rise"><PageHeading eyebrow={`Stock flow / ${isReceipt ? 'inbound' : 'outbound'}`} title={title} detail={isReceipt ? 'Register and validate stock arriving at your locations.' : 'Stage and release stock leaving your locations.'} action={<Button onClick={() => setOpen(true)} testId={`button-create-${kind.slice(0, -1)}`}><Plus className="h-4 w-4" /> New {isReceipt ? 'receipt' : 'delivery'}</Button>} /><DocumentSummary items={items} /><div className="mt-5 overflow-hidden rounded-lg border border-card-border bg-card shadow-sm">{query.isLoading ? <LoadingRows /> : query.isError ? <QueryState error={query.error} onRetry={() => query.refetch()} /> : !items.length ? <EmptyState title={`No ${kind} recorded`} detail={`Create a ${isReceipt ? 'receipt' : 'delivery'} to start the flow.`} /> : <div className="overflow-x-auto"><table className="w-full min-w-[780px] text-left"><thead className="bg-muted/60 text-[10px] uppercase tracking-[.14em] text-muted-foreground"><tr><th className="px-5 py-3">Reference</th><th className="px-3 py-3">Partner</th><th className="px-3 py-3">Location</th><th className="px-3 py-3">Date</th><th className="px-3 py-3">Lines</th><th className="px-3 py-3">Status</th><th className="px-5 py-3" /></tr></thead><tbody className="divide-y divide-border">{items.map((item) => <tr key={item.id} data-testid={`row-${kind}-${item.id}`} className="hover:bg-muted/40"><td className="px-5 py-4 font-mono-ui text-xs font-medium">{item.reference}</td><td className="px-3 py-4 text-sm font-semibold">{item.partner}</td><td className="px-3 py-4 text-xs text-muted-foreground">{item.location}</td><td className="px-3 py-4 text-xs text-muted-foreground">{dateLabel(item.date)}</td><td className="px-3 py-4 text-xs"><span className="font-mono-ui">{item.lineCount}</span> <span className="text-muted-foreground">/ {formatNumber(item.totalUnits)} units</span></td><td className="px-3 py-4"><StatusPill status={item.status} /></td><td className="px-5 py-4 text-right">{item.status !== 'done' && item.status !== 'canceled' && <Button onClick={() => validate(item.id)} variant="secondary" testId={`button-validate-${kind}-${item.id}`}><Check className="h-3.5 w-3.5 text-primary" /> Validate</Button>}</td></tr>)}</tbody></table></div>}</div>
    <Modal title={`New ${isReceipt ? 'receipt' : 'delivery'}`} open={open} onClose={() => setOpen(false)}><form onSubmit={submit} className="grid gap-4"><Field label={isReceipt ? 'Supplier' : 'Customer'}><TextInput required data-testid={`input-${kind}-partner`} value={form.partner} onChange={(e) => setForm({ ...form, partner: e.target.value })} placeholder={isReceipt ? 'Supplier or ASN reference' : 'Customer or order reference'} /></Field><Field label="Destination location"><select required data-testid={`select-${kind}-location`} value={form.location} onChange={(e) => setForm({ ...form, location: e.target.value })} className="focus-ring h-10 rounded-md border border-input bg-background px-3 text-sm"><option value="">Select location</option>{(warehouses.data as { locations?: { name: string }[] }[] | undefined)?.flatMap((w) => w.locations ?? []).map((l) => <option key={l.name} value={l.name}>{l.name}</option>)}</select></Field><Field label="Product"><select required data-testid={`select-${kind}-product`} value={form.productId} onChange={(e) => setForm({ ...form, productId: e.target.value })} className="focus-ring h-10 rounded-md border border-input bg-background px-3 text-sm"><option value="">Select product</option>{(products.data as Product[] | undefined)?.map((p) => <option key={p.id} value={p.id}>{p.name} · {p.sku}</option>)}</select></Field><Field label="Quantity"><TextInput required min="1" type="number" data-testid={`input-${kind}-quantity`} value={form.quantity} onChange={(e) => setForm({ ...form, quantity: e.target.value })} /></Field><Button type="submit" testId={`button-submit-${kind}`}>Create {isReceipt ? 'receipt' : 'delivery'}</Button></form></Modal>
  </div>;
}

function DocumentSummary({ items }: { items: StockDocument[] }) {
  return <div className="grid grid-cols-3 gap-3">{[['Open', items.filter((i) => i.status !== 'done' && i.status !== 'canceled').length], ['Validated', items.filter((i) => i.status === 'done').length], ['Units staged', items.reduce((sum, i) => sum + (i.totalUnits || 0), 0)]].map(([label, value]) => <div key={label} className="rounded-lg border border-card-border bg-card p-4 shadow-sm"><p className="text-[10px] font-bold uppercase tracking-[.16em] text-muted-foreground">{label}</p><p className="mt-2 font-mono-ui text-xl">{formatNumber(Number(value))}</p></div>)}</div>;
}

function TransfersPage() {
  const query = useListTransfers();
  const products = useListProducts();
  const warehouses = useListWarehouses();
  const create = useCreateTransfer();
  const validate = useValidateTransfer();
  const [open, setOpen] = useState(false);
  const [form, setForm] = useState({ productId: '', quantity: '1', fromLocation: '', toLocation: '' });
  const items = (query.data as Transfer[] | undefined) ?? [];
  const locations = (warehouses.data as { locations?: { name: string }[] }[] | undefined)?.flatMap((w) => w.locations ?? []) ?? [];
  const submit = (event: React.FormEvent) => { event.preventDefault(); create.mutate({ data: { productId: Number(form.productId), quantity: Number(form.quantity), fromLocation: form.fromLocation, toLocation: form.toLocation } }, { onSuccess: () => { queryClient.invalidateQueries({ queryKey: getListTransfersQueryKey() }); queryClient.invalidateQueries({ queryKey: getGetDashboardSummaryQueryKey() }); setOpen(false); } }); };
  return <div className="animate-rise"><PageHeading eyebrow="Stock flow / movement" title="Internal transfers" detail="Move inventory between locations without losing the chain of custody." action={<Button onClick={() => setOpen(true)} testId="button-create-transfer"><Plus className="h-4 w-4" /> New transfer</Button>} /><div className="mt-5 overflow-hidden rounded-lg border border-card-border bg-card shadow-sm">{query.isLoading ? <LoadingRows /> : query.isError ? <QueryState error={query.error} onRetry={() => query.refetch()} /> : !items.length ? <EmptyState title="No transfers queued" detail="Create an internal transfer when stock needs to move." /> : <div className="overflow-x-auto"><table className="w-full min-w-[780px] text-left"><thead className="bg-muted/60 text-[10px] uppercase tracking-[.14em] text-muted-foreground"><tr><th className="px-5 py-3">Reference</th><th className="px-3 py-3">Product</th><th className="px-3 py-3">Quantity</th><th className="px-3 py-3">Route</th><th className="px-3 py-3">Status</th><th className="px-5 py-3" /></tr></thead><tbody className="divide-y divide-border">{items.map((item) => <tr key={item.id} data-testid={`row-transfer-${item.id}`} className="hover:bg-muted/40"><td className="px-5 py-4 font-mono-ui text-xs">{item.reference}</td><td className="px-3 py-4 text-sm font-semibold">{item.productName}</td><td className="px-3 py-4 font-mono-ui text-xs">{formatNumber(item.quantity)}</td><td className="px-3 py-4 text-xs"><span>{item.fromLocation}</span><ArrowRight className="mx-2 inline h-3 w-3 text-primary" /><span>{item.toLocation}</span></td><td className="px-3 py-4"><StatusPill status={item.status} /></td><td className="px-5 py-4 text-right">{item.status !== 'done' && item.status !== 'canceled' && <Button variant="secondary" onClick={() => validate.mutate({ id: item.id }, { onSuccess: () => { queryClient.invalidateQueries({ queryKey: getListTransfersQueryKey() }); queryClient.invalidateQueries({ queryKey: getGetDashboardSummaryQueryKey() }); } })} testId={`button-validate-transfer-${item.id}`}><Check className="h-3.5 w-3.5 text-primary" /> Validate</Button>}</td></tr>)}</tbody></table></div>}</div><Modal title="New transfer" open={open} onClose={() => setOpen(false)}><form onSubmit={submit} className="grid gap-4"><Field label="Product"><select required data-testid="select-transfer-product" value={form.productId} onChange={(e) => setForm({ ...form, productId: e.target.value })} className="focus-ring h-10 rounded-md border border-input bg-background px-3 text-sm"><option value="">Select product</option>{(products.data as Product[] | undefined)?.map((p) => <option key={p.id} value={p.id}>{p.name}</option>)}</select></Field><Field label="Quantity"><TextInput required type="number" min="1" data-testid="input-transfer-quantity" value={form.quantity} onChange={(e) => setForm({ ...form, quantity: e.target.value })} /></Field><div className="grid grid-cols-2 gap-3"><Field label="From"><select required data-testid="select-transfer-from" value={form.fromLocation} onChange={(e) => setForm({ ...form, fromLocation: e.target.value })} className="focus-ring h-10 rounded-md border border-input bg-background px-2 text-sm"><option value="">Location</option>{locations.map((l) => <option key={l.name} value={l.name}>{l.name}</option>)}</select></Field><Field label="To"><select required data-testid="select-transfer-to" value={form.toLocation} onChange={(e) => setForm({ ...form, toLocation: e.target.value })} className="focus-ring h-10 rounded-md border border-input bg-background px-2 text-sm"><option value="">Location</option>{locations.map((l) => <option key={l.name} value={l.name}>{l.name}</option>)}</select></Field></div><Button type="submit" testId="button-submit-transfer">Create transfer</Button></form></Modal></div>;
}

function AdjustmentsPage() {
  const query = useListAdjustments();
  const products = useListProducts();
  const warehouses = useListWarehouses();
  const create = useCreateAdjustment();
  const validate = useValidateAdjustment();
  const [open, setOpen] = useState(false);
  const [form, setForm] = useState({ productId: '', location: '', countedQuantity: '0' });
  const items = (query.data as Adjustment[] | undefined) ?? [];
  const locations = (warehouses.data as { locations?: { name: string }[] }[] | undefined)?.flatMap((w) => w.locations ?? []) ?? [];
  const submit = (event: React.FormEvent) => { event.preventDefault(); create.mutate({ data: { productId: Number(form.productId), location: form.location, countedQuantity: Number(form.countedQuantity) } }, { onSuccess: () => { queryClient.invalidateQueries({ queryKey: getListAdjustmentsQueryKey() }); setOpen(false); } }); };
  return <div className="animate-rise"><PageHeading eyebrow="Stock accuracy / count" title="Adjustments" detail="Reconcile physical counts against the system of record." action={<Button onClick={() => setOpen(true)} testId="button-create-adjustment"><Plus className="h-4 w-4" /> New count</Button>} /><div className="mt-5 overflow-hidden rounded-lg border border-card-border bg-card shadow-sm">{query.isLoading ? <LoadingRows /> : query.isError ? <QueryState error={query.error} onRetry={() => query.refetch()} /> : !items.length ? <EmptyState title="No count adjustments" detail="Start a count to reconcile a location." /> : <div className="overflow-x-auto"><table className="w-full min-w-[760px] text-left"><thead className="bg-muted/60 text-[10px] uppercase tracking-[.14em] text-muted-foreground"><tr><th className="px-5 py-3">Reference</th><th className="px-3 py-3">Product</th><th className="px-3 py-3">Location</th><th className="px-3 py-3">System</th><th className="px-3 py-3">Counted</th><th className="px-3 py-3">Delta</th><th className="px-5 py-3" /></tr></thead><tbody className="divide-y divide-border">{items.map((item) => <tr key={item.id} data-testid={`row-adjustment-${item.id}`} className="hover:bg-muted/40"><td className="px-5 py-4 font-mono-ui text-xs">{item.reference}</td><td className="px-3 py-4 text-sm font-semibold">{item.productName}</td><td className="px-3 py-4 text-xs text-muted-foreground">{item.location}</td><td className="px-3 py-4 font-mono-ui text-xs">{item.systemQuantity}</td><td className="px-3 py-4 font-mono-ui text-xs">{item.countedQuantity}</td><td className={`px-3 py-4 font-mono-ui text-xs font-medium ${item.delta < 0 ? 'text-destructive' : 'text-primary'}`}>{item.delta > 0 ? '+' : ''}{item.delta}</td><td className="px-5 py-4 text-right">{item.status !== 'done' && <Button variant="secondary" onClick={() => validate.mutate({ id: item.id }, { onSuccess: () => { queryClient.invalidateQueries({ queryKey: getListAdjustmentsQueryKey() }); queryClient.invalidateQueries({ queryKey: getGetDashboardSummaryQueryKey() }); } })} testId={`button-validate-adjustment-${item.id}`}><Check className="h-3.5 w-3.5 text-primary" /> Apply</Button>}</td></tr>)}</tbody></table></div>}</div><Modal title="New physical count" open={open} onClose={() => setOpen(false)}><form onSubmit={submit} className="grid gap-4"><Field label="Product"><select required data-testid="select-adjustment-product" value={form.productId} onChange={(e) => setForm({ ...form, productId: e.target.value })} className="focus-ring h-10 rounded-md border border-input bg-background px-3 text-sm"><option value="">Select product</option>{(products.data as Product[] | undefined)?.map((p) => <option key={p.id} value={p.id}>{p.name}</option>)}</select></Field><Field label="Location"><select required data-testid="select-adjustment-location" value={form.location} onChange={(e) => setForm({ ...form, location: e.target.value })} className="focus-ring h-10 rounded-md border border-input bg-background px-3 text-sm"><option value="">Select location</option>{locations.map((l) => <option key={l.name} value={l.name}>{l.name}</option>)}</select></Field><Field label="Counted quantity"><TextInput required type="number" min="0" data-testid="input-adjustment-count" value={form.countedQuantity} onChange={(e) => setForm({ ...form, countedQuantity: e.target.value })} /></Field><Button type="submit" testId="button-submit-adjustment">Save count</Button></form></Modal></div>;
}

function LedgerPage() {
  const [search, setSearch] = useState('');
  const [type, setType] = useState('');
  const query = useListLedger({ search: search || undefined, type: type || undefined });
  const items = (query.data as LedgerEntry[] | undefined) ?? [];
  return <div className="animate-rise"><PageHeading eyebrow="Audit / movement history" title="Stock ledger" detail="One source of truth for every movement and correction." /><div className="mb-4 flex flex-col gap-2 sm:flex-row"><div className="relative flex-1"><Search className="absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-muted-foreground" /><TextInput data-testid="input-ledger-search" value={search} onChange={(e) => setSearch(e.target.value)} placeholder="Search reference, product, or operator" className="pl-9" /></div><select data-testid="select-ledger-type" value={type} onChange={(e) => setType(e.target.value)} className="focus-ring h-10 rounded-md border border-input bg-card px-3 text-xs font-semibold"><option value="">All movement types</option><option value="receipt">Receipts</option><option value="delivery">Deliveries</option><option value="transfer">Transfers</option><option value="adjustment">Adjustments</option></select></div><div className="overflow-hidden rounded-lg border border-card-border bg-card shadow-sm">{query.isLoading ? <LoadingRows /> : query.isError ? <QueryState error={query.error} onRetry={() => query.refetch()} /> : !items.length ? <EmptyState title="No ledger entries" detail="Stock movements will appear as documents are validated." /> : <div className="overflow-x-auto"><table className="w-full min-w-[900px] text-left"><thead className="bg-muted/60 text-[10px] uppercase tracking-[.14em] text-muted-foreground"><tr><th className="px-5 py-3">Date</th><th className="px-3 py-3">Type</th><th className="px-3 py-3">Reference</th><th className="px-3 py-3">Product</th><th className="px-3 py-3">Location</th><th className="px-3 py-3">Quantity</th><th className="px-5 py-3">Performed by</th></tr></thead><tbody className="divide-y divide-border">{items.map((item) => <tr key={item.id} data-testid={`row-ledger-${item.id}`} className="hover:bg-muted/40"><td className="px-5 py-4 text-xs text-muted-foreground">{dateLabel(item.date)}</td><td className="px-3 py-4"><span className="rounded bg-secondary px-2 py-1 text-[10px] font-bold uppercase">{item.type}</span></td><td className="px-3 py-4 font-mono-ui text-xs">{item.reference}</td><td className="px-3 py-4 text-sm font-semibold">{item.productName}</td><td className="px-3 py-4 text-xs text-muted-foreground">{item.location}</td><td className={`px-3 py-4 font-mono-ui text-xs font-medium ${item.direction === 'out' ? 'text-destructive' : 'text-primary'}`}>{item.direction === 'out' ? '−' : item.direction === 'in' ? '+' : ''}{formatNumber(item.quantity)}</td><td className="px-5 py-4 text-xs text-muted-foreground">{item.performedBy}</td></tr>)}</tbody></table></div>}</div></div>;
}

function SettingsPage() {
  const categories = useListCategories();
  const warehouses = useListWarehouses();
  const createCategory = useCreateCategory();
  const createWarehouse = useCreateWarehouse();
  const [category, setCategory] = useState({ name: '', color: '#0f766e' });
  const [warehouse, setWarehouse] = useState({ name: '', code: '', locationName: '' });
  const submitCategory = (event: React.FormEvent) => { event.preventDefault(); createCategory.mutate({ data: category }, { onSuccess: () => { queryClient.invalidateQueries({ queryKey: getListCategoriesQueryKey() }); setCategory({ name: '', color: '#0f766e' }); } }); };
  const submitWarehouse = (event: React.FormEvent) => { event.preventDefault(); createWarehouse.mutate({ data: warehouse }, { onSuccess: () => { queryClient.invalidateQueries({ queryKey: getListWarehousesQueryKey() }); setWarehouse({ name: '', code: '', locationName: '' }); } }); };
  return <div className="animate-rise"><PageHeading eyebrow="Configuration / network" title="Settings" detail="Keep the operational model clean and ready for the floor." /><div className="grid gap-5 xl:grid-cols-2"><section className="rounded-lg border border-card-border bg-card p-5 shadow-sm"><div className="mb-5 flex items-start justify-between"><div><div className="grid h-9 w-9 place-items-center rounded-md bg-primary/10 text-primary"><Tags className="h-4 w-4" /></div><h3 className="mt-3 font-bold">Categories</h3><p className="mt-1 text-xs text-muted-foreground">Organize product lines for faster decisions.</p></div><span className="font-mono-ui text-xs text-muted-foreground">{(categories.data as unknown[] | undefined)?.length ?? 0} total</span></div><div className="mb-5 space-y-2">{categories.isLoading ? <LoadingRows count={2} /> : (categories.data as { id: number; name: string; productCount: number; color: string }[] | undefined)?.map((item) => <div key={item.id} data-testid={`row-category-setting-${item.id}`} className="flex items-center gap-3 rounded-md border border-border p-3"><span className="h-3 w-3 rounded-full" style={{ background: item.color }} /><span className="flex-1 text-sm font-semibold">{item.name}</span><span className="font-mono-ui text-[11px] text-muted-foreground">{item.productCount} products</span></div>)}</div><form onSubmit={submitCategory} className="grid gap-3 border-t border-border pt-4"><p className="text-xs font-bold uppercase tracking-wider text-muted-foreground">Add category</p><div className="flex gap-2"><TextInput required data-testid="input-category-name" value={category.name} onChange={(e) => setCategory({ ...category, name: e.target.value })} placeholder="Category name" /><input aria-label="Category color" data-testid="input-category-color" type="color" value={category.color} onChange={(e) => setCategory({ ...category, color: e.target.value })} className="h-10 w-12 rounded border border-input bg-background p-1" /><Button type="submit" testId="button-submit-category"><Plus className="h-4 w-4" /> Add</Button></div></form></section><section className="rounded-lg border border-card-border bg-card p-5 shadow-sm"><div className="mb-5 flex items-start justify-between"><div><div className="grid h-9 w-9 place-items-center rounded-md bg-accent/15 text-amber-700"><WarehouseIcon className="h-4 w-4" /></div><h3 className="mt-3 font-bold">Warehouses & locations</h3><p className="mt-1 text-xs text-muted-foreground">Map where inventory physically lives.</p></div><span className="font-mono-ui text-xs text-muted-foreground">{(warehouses.data as unknown[] | undefined)?.length ?? 0} total</span></div><div className="mb-5 space-y-2">{warehouses.isLoading ? <LoadingRows count={2} /> : (warehouses.data as { id: number; name: string; code: string; totalUnits: number; locations: { name: string }[] }[] | undefined)?.map((item) => <div key={item.id} data-testid={`row-warehouse-${item.id}`} className="rounded-md border border-border p-3"><div className="flex items-center gap-3"><span className="grid h-7 w-7 place-items-center rounded bg-secondary font-mono-ui text-[10px]">{item.code}</span><span className="flex-1 text-sm font-semibold">{item.name}</span><span className="font-mono-ui text-[11px] text-muted-foreground">{formatNumber(item.totalUnits)} units</span></div><p className="mt-2 pl-10 text-[11px] text-muted-foreground">{item.locations?.map((l) => l.name).join(' · ') || 'No locations configured'}</p></div>)}</div><form onSubmit={submitWarehouse} className="grid gap-3 border-t border-border pt-4"><p className="text-xs font-bold uppercase tracking-wider text-muted-foreground">Add warehouse</p><div className="grid grid-cols-2 gap-2"><TextInput required data-testid="input-warehouse-name" value={warehouse.name} onChange={(e) => setWarehouse({ ...warehouse, name: e.target.value })} placeholder="Warehouse name" /><TextInput required data-testid="input-warehouse-code" value={warehouse.code} onChange={(e) => setWarehouse({ ...warehouse, code: e.target.value })} placeholder="Code" /></div><div className="flex gap-2"><TextInput required data-testid="input-location-name" value={warehouse.locationName} onChange={(e) => setWarehouse({ ...warehouse, locationName: e.target.value })} placeholder="First location name" /><Button type="submit" testId="button-submit-warehouse"><Plus className="h-4 w-4" /> Add</Button></div></form></section></div><section className="mt-5 rounded-lg border border-card-border bg-card p-5 shadow-sm"><div className="flex items-center gap-3"><SlidersHorizontal className="h-4 w-4 text-primary" /><div><h3 className="font-bold">Reorder configuration</h3><p className="text-xs text-muted-foreground">Reorder points are managed per product in the catalog.</p></div><Link href="/products" data-testid="link-settings-products" className="ml-auto text-xs font-bold text-primary">Manage products <ArrowRight className="ml-1 inline h-3 w-3" /></Link></div></section></div>;
}

function ProfilePage() {
  const { signOut } = useClerk();
  const { user } = useUser();
  const email = user?.primaryEmailAddress?.emailAddress ?? 'morgan.chen@northstar.co';
  return <div className="animate-rise max-w-3xl"><PageHeading eyebrow="Account / operator" title="Profile" detail="Your operator identity and workspace access." /><div className="grid gap-5 md:grid-cols-[220px_1fr]"><aside className="rounded-lg border border-card-border bg-card p-5 shadow-sm"><div className="grid h-20 w-20 place-items-center rounded-full bg-accent text-2xl font-extrabold text-accent-foreground">{user?.firstName?.slice(0, 1) ?? 'MC'}</div><h3 className="mt-4 font-bold">{user?.fullName ?? 'Morgan Chen'}</h3><p className="text-xs text-muted-foreground">Inventory manager</p><div className="mt-5 rounded-md bg-primary/5 p-3"><p className="font-mono-ui text-[10px] uppercase tracking-wider text-primary">Access level</p><p className="mt-1 text-xs font-bold">Operations admin</p></div><button onClick={() => signOut({ redirectUrl: basePath || '/' })} data-testid="button-logout" className="mt-5 text-xs font-bold text-destructive hover:underline">Log out</button></aside><section className="rounded-lg border border-card-border bg-card p-5 shadow-sm"><div className="mb-5 border-b border-border pb-4"><h3 className="font-bold">Account details</h3><p className="mt-1 text-xs text-muted-foreground">Used for activity attribution and notifications.</p></div><div className="grid gap-4 sm:grid-cols-2"><Field label="Full name"><TextInput data-testid="input-profile-name" defaultValue={user?.fullName ?? 'Morgan Chen'} /></Field><Field label="Role"><TextInput data-testid="input-profile-role" defaultValue="Inventory manager" /></Field><Field label="Email"><TextInput data-testid="input-profile-email" defaultValue={email} type="email" /></Field><Field label="Time zone"><select data-testid="select-profile-timezone" className="focus-ring h-10 rounded-md border border-input bg-background px-3 text-sm"><option>Pacific Time (PT)</option><option>Central Time (CT)</option><option>Eastern Time (ET)</option></select></Field></div><div className="mt-6 flex justify-end"><Button onClick={() => undefined} testId="button-save-profile"><CircleCheck className="h-4 w-4" /> Save changes</Button></div></section></div></div>;
}

function SignInPage() {
  return <div className="flex min-h-[100dvh] items-center justify-center bg-background px-4"><SignIn routing="path" path={`${basePath}/sign-in`} signUpUrl={`${basePath}/sign-up`} /></div>;
}

function SignUpPage() {
  return <div className="flex min-h-[100dvh] items-center justify-center bg-background px-4"><SignUp routing="path" path={`${basePath}/sign-up`} signInUrl={`${basePath}/sign-in`} /></div>;
}

function Router() {
  const [location] = useLocation();
  return <ErrorBoundary resetKey={location}><Switch><Route path="/sign-in/*?" component={SignInPage} /><Route path="/sign-up/*?" component={SignUpPage} /><Route><Shell><Switch><Route path="/" component={Dashboard} /><Route path="/products" component={ProductPage} /><Route path="/receipts"><DocumentsPage kind="receipts" /></Route><Route path="/deliveries"><DocumentsPage kind="deliveries" /></Route><Route path="/transfers" component={TransfersPage} /><Route path="/adjustments" component={AdjustmentsPage} /><Route path="/ledger" component={LedgerPage} /><Route path="/settings" component={SettingsPage} /><Route path="/profile" component={ProfilePage} /><Route component={NotFound} /></Switch></Shell></Route></Switch></ErrorBoundary>;
}

function App() {
  return <WouterRouter base={basePath}><ClerkProvider publishableKey={clerkPubKey} proxyUrl={clerkProxyUrl} appearance={clerkAppearance} signInUrl={`${basePath}/sign-in`} signUpUrl={`${basePath}/sign-up`} localization={{ signIn: { start: { title: 'Welcome back', subtitle: 'Sign in to access StockSense' } }, signUp: { start: { title: 'Create your StockSense account', subtitle: 'Start managing inventory with confidence' } } }}><QueryClientProvider client={queryClient}><TooltipProvider><Router /><Toaster /></TooltipProvider></QueryClientProvider></ClerkProvider></WouterRouter>;
}

export default App;