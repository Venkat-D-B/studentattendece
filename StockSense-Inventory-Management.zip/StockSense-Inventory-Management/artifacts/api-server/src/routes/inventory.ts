import { Router, type IRouter } from "express";
import {
  CreateAdjustmentBody,
  CreateCategoryBody,
  CreateDeliveryBody,
  CreateProductBody,
  CreateReceiptBody,
  CreateTransferBody,
  CreateWarehouseBody,
  GetRecentActivityQueryParams,
  ListLedgerQueryParams,
  ListProductsQueryParams,
  UpdateProductBody,
} from "@workspace/api-zod";

type Status = "draft" | "waiting" | "ready" | "done" | "canceled";
type ProductStatus = "healthy" | "low" | "out";
type MovementType = "receipt" | "delivery" | "transfer" | "adjustment";

type LocationStock = { location: string; units: number };
type Product = {
  id: number;
  name: string;
  sku: string;
  category: string;
  unit: string;
  totalStock: number;
  reorderPoint: number;
  locations: LocationStock[];
  status: ProductStatus;
  updatedAt: string;
};
type StockLine = {
  productId: number;
  productName: string;
  sku: string;
  quantity: number;
  unit: string;
};
type StockDocument = {
  id: number;
  reference: string;
  partner: string;
  location: string;
  status: Status;
  date: string;
  lineCount: number;
  totalUnits: number;
  lines: StockLine[];
};
type Transfer = {
  id: number;
  reference: string;
  productName: string;
  quantity: number;
  fromLocation: string;
  toLocation: string;
  status: Status;
  date: string;
};
type Adjustment = {
  id: number;
  reference: string;
  productName: string;
  location: string;
  systemQuantity: number;
  countedQuantity: number;
  delta: number;
  status: "draft" | "done";
  date: string;
};
type LedgerEntry = {
  id: number;
  date: string;
  type: MovementType;
  reference: string;
  productName: string;
  location: string;
  quantity: number;
  direction: "in" | "out" | "move" | "correction";
  performedBy: string;
};

const now = new Date();
const day = (offset: number) =>
  new Date(now.getTime() - offset * 86_400_000).toISOString();

const products: Product[] = [
  {
    id: 1,
    name: "Steel Rods",
    sku: "STL-100",
    category: "Raw materials",
    unit: "pcs",
    totalStock: 240,
    reorderPoint: 80,
    locations: [
      { location: "Main Warehouse · Rack A", units: 180 },
      { location: "Production Floor", units: 60 },
    ],
    status: "healthy",
    updatedAt: day(0),
  },
  {
    id: 2,
    name: "Office Chairs",
    sku: "CHR-204",
    category: "Furniture",
    unit: "pcs",
    totalStock: 18,
    reorderPoint: 25,
    locations: [
      { location: "Main Warehouse · Rack B", units: 8 },
      { location: "Showroom", units: 10 },
    ],
    status: "low",
    updatedAt: day(1),
  },
  {
    id: 3,
    name: "Packaging Boxes",
    sku: "PKG-550",
    category: "Packaging",
    unit: "pcs",
    totalStock: 0,
    reorderPoint: 50,
    locations: [{ location: "Main Warehouse · Rack C", units: 0 }],
    status: "out",
    updatedAt: day(2),
  },
  {
    id: 4,
    name: "LED Panels",
    sku: "LGT-320",
    category: "Lighting",
    unit: "pcs",
    totalStock: 84,
    reorderPoint: 30,
    locations: [{ location: "Warehouse 2 · Rack B", units: 84 }],
    status: "healthy",
    updatedAt: day(3),
  },
  {
    id: 5,
    name: "Copper Wire",
    sku: "CPR-120",
    category: "Raw materials",
    unit: "rolls",
    totalStock: 42,
    reorderPoint: 20,
    locations: [{ location: "Main Warehouse · Rack D", units: 42 }],
    status: "healthy",
    updatedAt: day(4),
  },
];

const categories = [
  { id: 1, name: "Raw materials", productCount: 2, color: "#2B6F68" },
  { id: 2, name: "Furniture", productCount: 1, color: "#CC7A42" },
  { id: 3, name: "Packaging", productCount: 1, color: "#D6A847" },
  { id: 4, name: "Lighting", productCount: 1, color: "#7A8DB3" },
];

const warehouses = [
  {
    id: 1,
    name: "Main Warehouse",
    code: "WH-01",
    locations: [
      { id: 1, name: "Rack A" },
      { id: 2, name: "Rack B" },
      { id: 3, name: "Rack C" },
      { id: 4, name: "Rack D" },
    ],
    totalUnits: 240,
  },
  {
    id: 2,
    name: "Production & Showroom",
    code: "WH-02",
    locations: [
      { id: 5, name: "Production Floor" },
      { id: 6, name: "Showroom" },
    ],
    totalUnits: 70,
  },
  {
    id: 3,
    name: "Warehouse 2",
    code: "WH-03",
    locations: [{ id: 7, name: "Rack B" }],
    totalUnits: 84,
  },
];

const receipts: StockDocument[] = [
  {
    id: 1,
    reference: "WH/IN/00041",
    partner: "Arcelor Materials",
    location: "Main Warehouse · Rack A",
    status: "waiting",
    date: day(0),
    lineCount: 2,
    totalUnits: 120,
    lines: [],
  },
  {
    id: 2,
    reference: "WH/IN/00040",
    partner: "Luma Electricals",
    location: "Warehouse 2 · Rack B",
    status: "ready",
    date: day(1),
    lineCount: 1,
    totalUnits: 60,
    lines: [],
  },
];

const deliveries: StockDocument[] = [
  {
    id: 1,
    reference: "WH/OUT/00028",
    partner: "Northstar Interiors",
    location: "Main Warehouse · Rack B",
    status: "ready",
    date: day(0),
    lineCount: 1,
    totalUnits: 10,
    lines: [],
  },
  {
    id: 2,
    reference: "WH/OUT/00027",
    partner: "Atlas Workspace",
    location: "Showroom",
    status: "waiting",
    date: day(2),
    lineCount: 2,
    totalUnits: 24,
    lines: [],
  },
];

const transfers: Transfer[] = [
  {
    id: 1,
    reference: "WH/TRF/00012",
    productName: "Steel Rods",
    quantity: 30,
    fromLocation: "Main Warehouse · Rack A",
    toLocation: "Production Floor",
    status: "ready",
    date: day(0),
  },
  {
    id: 2,
    reference: "WH/TRF/00011",
    productName: "LED Panels",
    quantity: 12,
    fromLocation: "Warehouse 2 · Rack B",
    toLocation: "Showroom",
    status: "waiting",
    date: day(3),
  },
];

const adjustments: Adjustment[] = [
  {
    id: 1,
    reference: "INV/ADJ/00008",
    productName: "Office Chairs",
    location: "Showroom",
    systemQuantity: 12,
    countedQuantity: 10,
    delta: -2,
    status: "draft",
    date: day(0),
  },
];

const ledger: LedgerEntry[] = [
  {
    id: 1,
    date: day(0),
    type: "receipt",
    reference: "WH/IN/00039",
    productName: "Steel Rods",
    location: "Main Warehouse · Rack A",
    quantity: 50,
    direction: "in",
    performedBy: "Maya Chen",
  },
  {
    id: 2,
    date: day(1),
    type: "delivery",
    reference: "WH/OUT/00026",
    productName: "Office Chairs",
    location: "Showroom",
    quantity: 6,
    direction: "out",
    performedBy: "Maya Chen",
  },
  {
    id: 3,
    date: day(2),
    type: "transfer",
    reference: "WH/TRF/00010",
    productName: "LED Panels",
    location: "Warehouse 2 → Showroom",
    quantity: 12,
    direction: "move",
    performedBy: "Jordan Lee",
  },
  {
    id: 4,
    date: day(3),
    type: "adjustment",
    reference: "INV/ADJ/00007",
    productName: "Copper Wire",
    location: "Main Warehouse · Rack D",
    quantity: 2,
    direction: "correction",
    performedBy: "Maya Chen",
  },
  {
    id: 5,
    date: day(4),
    type: "receipt",
    reference: "WH/IN/00038",
    productName: "Packaging Boxes",
    location: "Main Warehouse · Rack C",
    quantity: 100,
    direction: "in",
    performedBy: "Jordan Lee",
  },
];

let nextId = 20;

const refreshProduct = (product: Product) => {
  product.totalStock = product.locations.reduce((sum, item) => sum + item.units, 0);
  product.status =
    product.totalStock === 0
      ? "out"
      : product.totalStock <= product.reorderPoint
        ? "low"
        : "healthy";
  product.updatedAt = new Date().toISOString();
};

const findProduct = (id: number) => products.find((product) => product.id === id);

const adjustLocation = (product: Product, location: string, delta: number) => {
  const existing = product.locations.find((item) => item.location === location);
  if (existing) existing.units = Math.max(0, existing.units + delta);
  else product.locations.push({ location, units: Math.max(0, delta) });
  refreshProduct(product);
};

const activityFor = (entry: LedgerEntry) => ({
  id: entry.id,
  type: entry.type,
  title:
    entry.type === "receipt"
      ? "Receipt validated"
      : entry.type === "delivery"
        ? "Delivery validated"
        : entry.type === "transfer"
          ? "Internal transfer completed"
          : "Stock count adjusted",
  detail: `${entry.reference} · ${entry.productName}`,
  quantity: entry.quantity,
  timestamp: entry.date,
  status: "done",
});

const router: IRouter = Router();

router.get("/dashboard/summary", (_req, res) => {
  const totalUnits = products.reduce((sum, product) => sum + product.totalStock, 0);
  const byCategory = categories.map((category) => {
    const units = products
      .filter((product) => product.category === category.name)
      .reduce((sum, product) => sum + product.totalStock, 0);
    return { category: category.name, units, percentage: totalUnits ? Math.round((units / totalUnits) * 100) : 0 };
  });
  res.json({
    totalUnits,
    productCount: products.length,
    lowStockCount: products.filter((product) => product.status === "low").length,
    outOfStockCount: products.filter((product) => product.status === "out").length,
    pendingReceipts: receipts.filter((item) => item.status !== "done" && item.status !== "canceled").length,
    pendingDeliveries: deliveries.filter((item) => item.status !== "done" && item.status !== "canceled").length,
    scheduledTransfers: transfers.filter((item) => item.status !== "done" && item.status !== "canceled").length,
    inboundValue: 12480,
    outboundValue: 8920,
    byCategory,
  });
});

router.get("/activity/recent", (req, res) => {
  const parsed = GetRecentActivityQueryParams.safeParse(req.query);
  const limit = parsed.success ? parsed.data.limit : 8;
  res.json(ledger.slice(0, limit).map(activityFor));
});

router.get("/products", (req, res) => {
  const parsed = ListProductsQueryParams.safeParse(req.query);
  const filters = parsed.success ? parsed.data : {};
  const search = filters.search?.toLowerCase();
  res.json(
    products.filter((product) => {
      const matchesSearch = !search || product.name.toLowerCase().includes(search) || product.sku.toLowerCase().includes(search);
      const matchesCategory = !filters.category || product.category === filters.category;
      const matchesStatus = !filters.stockStatus || filters.stockStatus === "all" || product.status === filters.stockStatus;
      return matchesSearch && matchesCategory && matchesStatus;
    }),
  );
});

router.post("/products", (req, res) => {
  const parsed = CreateProductBody.safeParse(req.body);
  if (!parsed.success) return res.status(400).json({ error: "Invalid product details" });
  const data = parsed.data;
  const product: Product = {
    id: nextId++,
    name: data.name,
    sku: data.sku,
    category: data.category,
    unit: data.unit,
    totalStock: data.initialStock,
    reorderPoint: data.reorderPoint,
    locations: [{ location: "Main Warehouse · Rack A", units: data.initialStock }],
    status: "healthy",
    updatedAt: new Date().toISOString(),
  };
  refreshProduct(product);
  products.unshift(product);
  return res.status(201).json(product);
});

router.get("/products/:id", (req, res) => {
  const product = findProduct(Number(req.params.id));
  if (!product) return res.status(404).json({ error: "Product not found" });
  return res.json(product);
});

router.patch("/products/:id", (req, res) => {
  const product = findProduct(Number(req.params.id));
  if (!product) return res.status(404).json({ error: "Product not found" });
  const parsed = UpdateProductBody.safeParse(req.body);
  if (!parsed.success) return res.status(400).json({ error: "Invalid product details" });
  Object.assign(product, parsed.data);
  refreshProduct(product);
  return res.json(product);
});

router.get("/categories", (_req, res) => res.json(categories));

router.post("/categories", (req, res) => {
  const parsed = CreateCategoryBody.safeParse(req.body);
  if (!parsed.success) return res.status(400).json({ error: "Invalid category details" });
  const category = { id: nextId++, name: parsed.data.name, productCount: 0, color: parsed.data.color ?? "#6F8D89" };
  categories.push(category);
  return res.status(201).json(category);
});

router.get("/warehouses", (_req, res) => res.json(warehouses));

router.post("/warehouses", (req, res) => {
  const parsed = CreateWarehouseBody.safeParse(req.body);
  if (!parsed.success) return res.status(400).json({ error: "Invalid warehouse details" });
  const warehouse = {
    id: nextId++,
    name: parsed.data.name,
    code: parsed.data.code,
    locations: [{ id: nextId++, name: parsed.data.locationName }],
    totalUnits: 0,
  };
  warehouses.push(warehouse);
  return res.status(201).json(warehouse);
});

router.get("/receipts", (_req, res) => res.json(receipts));

router.post("/receipts", (req, res) => {
  const parsed = CreateReceiptBody.safeParse(req.body);
  if (!parsed.success) return res.status(400).json({ error: "Invalid receipt details" });
  const product = findProduct(parsed.data.productId);
  if (!product) return res.status(404).json({ error: "Product not found" });
  const receipt: StockDocument = {
    id: nextId++,
    reference: `WH/IN/${String(nextId).padStart(5, "0")}`,
    partner: parsed.data.partner,
    location: parsed.data.location,
    status: "ready",
    date: new Date().toISOString(),
    lineCount: 1,
    totalUnits: parsed.data.quantity,
    lines: [{ productId: product.id, productName: product.name, sku: product.sku, quantity: parsed.data.quantity, unit: product.unit }],
  };
  receipts.unshift(receipt);
  return res.status(201).json(receipt);
});

router.post("/receipts/:id/validate", (req, res) => {
  const receipt = receipts.find((item) => item.id === Number(req.params.id));
  if (!receipt) return res.status(404).json({ error: "Receipt not found" });
  if (receipt.status === "done") return res.json(receipt);
  const line = receipt.lines[0];
  if (line) {
    const product = findProduct(line.productId);
    if (product) adjustLocation(product, receipt.location, line.quantity);
    ledger.unshift({ id: nextId++, date: new Date().toISOString(), type: "receipt", reference: receipt.reference, productName: line.productName, location: receipt.location, quantity: line.quantity, direction: "in", performedBy: "Maya Chen" });
  }
  receipt.status = "done";
  return res.json(receipt);
});

router.get("/deliveries", (_req, res) => res.json(deliveries));

router.post("/deliveries", (req, res) => {
  const parsed = CreateDeliveryBody.safeParse(req.body);
  if (!parsed.success) return res.status(400).json({ error: "Invalid delivery details" });
  const product = findProduct(parsed.data.productId);
  if (!product) return res.status(404).json({ error: "Product not found" });
  const delivery: StockDocument = {
    id: nextId++,
    reference: `WH/OUT/${String(nextId).padStart(5, "0")}`,
    partner: parsed.data.partner,
    location: parsed.data.location,
    status: "ready",
    date: new Date().toISOString(),
    lineCount: 1,
    totalUnits: parsed.data.quantity,
    lines: [{ productId: product.id, productName: product.name, sku: product.sku, quantity: parsed.data.quantity, unit: product.unit }],
  };
  deliveries.unshift(delivery);
  return res.status(201).json(delivery);
});

router.post("/deliveries/:id/validate", (req, res) => {
  const delivery = deliveries.find((item) => item.id === Number(req.params.id));
  if (!delivery) return res.status(404).json({ error: "Delivery not found" });
  if (delivery.status === "done") return res.json(delivery);
  const line = delivery.lines[0];
  if (line) {
    const product = findProduct(line.productId);
    if (product) {
      const available = product.locations.find((item) => item.location === delivery.location)?.units ?? 0;
      if (available < line.quantity) return res.status(400).json({ error: "Not enough stock at this location" });
      adjustLocation(product, delivery.location, -line.quantity);
    }
    ledger.unshift({ id: nextId++, date: new Date().toISOString(), type: "delivery", reference: delivery.reference, productName: line.productName, location: delivery.location, quantity: line.quantity, direction: "out", performedBy: "Maya Chen" });
  }
  delivery.status = "done";
  return res.json(delivery);
});

router.get("/transfers", (_req, res) => res.json(transfers));

router.post("/transfers", (req, res) => {
  const parsed = CreateTransferBody.safeParse(req.body);
  if (!parsed.success) return res.status(400).json({ error: "Invalid transfer details" });
  const product = findProduct(parsed.data.productId);
  if (!product) return res.status(404).json({ error: "Product not found" });
  const transfer: Transfer = {
    id: nextId++,
    reference: `WH/TRF/${String(nextId).padStart(5, "0")}`,
    productName: product.name,
    quantity: parsed.data.quantity,
    fromLocation: parsed.data.fromLocation,
    toLocation: parsed.data.toLocation,
    status: "ready",
    date: new Date().toISOString(),
  };
  transfers.unshift(transfer);
  return res.status(201).json(transfer);
});

router.post("/transfers/:id/validate", (req, res) => {
  const transfer = transfers.find((item) => item.id === Number(req.params.id));
  if (!transfer) return res.status(404).json({ error: "Transfer not found" });
  if (transfer.status === "done") return res.json(transfer);
  const product = products.find((item) => item.name === transfer.productName);
  if (product) {
    const available = product.locations.find((item) => item.location === transfer.fromLocation)?.units ?? 0;
    if (available < transfer.quantity) return res.status(400).json({ error: "Not enough stock at source location" });
    adjustLocation(product, transfer.fromLocation, -transfer.quantity);
    adjustLocation(product, transfer.toLocation, transfer.quantity);
    ledger.unshift({ id: nextId++, date: new Date().toISOString(), type: "transfer", reference: transfer.reference, productName: transfer.productName, location: `${transfer.fromLocation} → ${transfer.toLocation}`, quantity: transfer.quantity, direction: "move", performedBy: "Jordan Lee" });
  }
  transfer.status = "done";
  return res.json(transfer);
});

router.get("/adjustments", (_req, res) => res.json(adjustments));

router.post("/adjustments", (req, res) => {
  const parsed = CreateAdjustmentBody.safeParse(req.body);
  if (!parsed.success) return res.status(400).json({ error: "Invalid adjustment details" });
  const product = findProduct(parsed.data.productId);
  if (!product) return res.status(404).json({ error: "Product not found" });
  const systemQuantity = product.locations.find((item) => item.location === parsed.data.location)?.units ?? 0;
  const adjustment: Adjustment = {
    id: nextId++,
    reference: `INV/ADJ/${String(nextId).padStart(5, "0")}`,
    productName: product.name,
    location: parsed.data.location,
    systemQuantity,
    countedQuantity: parsed.data.countedQuantity,
    delta: parsed.data.countedQuantity - systemQuantity,
    status: "draft",
    date: new Date().toISOString(),
  };
  adjustments.unshift(adjustment);
  return res.status(201).json(adjustment);
});

router.post("/adjustments/:id/validate", (req, res) => {
  const adjustment = adjustments.find((item) => item.id === Number(req.params.id));
  if (!adjustment) return res.status(404).json({ error: "Adjustment not found" });
  if (adjustment.status === "done") return res.json(adjustment);
  const product = products.find((item) => item.name === adjustment.productName);
  if (product) {
    adjustLocation(product, adjustment.location, adjustment.delta);
    ledger.unshift({ id: nextId++, date: new Date().toISOString(), type: "adjustment", reference: adjustment.reference, productName: adjustment.productName, location: adjustment.location, quantity: Math.abs(adjustment.delta), direction: "correction", performedBy: "Maya Chen" });
  }
  adjustment.status = "done";
  return res.json(adjustment);
});

router.get("/ledger", (req, res) => {
  const parsed = ListLedgerQueryParams.safeParse(req.query);
  const filters = parsed.success ? parsed.data : {};
  const search = filters.search?.toLowerCase();
  res.json(
    ledger.filter((entry) => {
      const typeMatches = !filters.type || entry.type === filters.type;
      const searchMatches = !search || `${entry.reference} ${entry.productName} ${entry.location}`.toLowerCase().includes(search);
      return typeMatches && searchMatches;
    }),
  );
});

export default router;